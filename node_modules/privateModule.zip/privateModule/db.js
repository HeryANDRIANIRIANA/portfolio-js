class Db{
	constructor(){
		this.cs='DSN=LAUVE-GRH';
		
	}
}
module.exports=Db;