const express = require('express');
const multer=require('multer');
const odbc = require('odbc');
const exceljs = require('exceljs');
const app = express();
const path = require('path');
const port = 3002;
const cors = require("cors");
const fs = require("fs");
app.use(cors());
app.use(express.json());

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Dossier où stocker les fichiers
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });

// privatesModules
const personnel=require('privateModule/personnel');
const paramSalaire=require('privateModule/paramSalaire');
const Db=require('privateModule/Db');
const etatSalaireBE=require('privateModule/etatSalaireBE');
const mois2BE=require('privateModule/mois2BE');
const avanceBE=require('privateModule/avanceBE');
const pointageBE=require('privateModule/pointageBE');
const heureSupBE=require('privateModule/heureSupBE');
const QmanagerBE=require('privateModule/QmanagerBE');
const dependencyes={exceljs:exceljs,personnel:personnel,paramSalaire:paramSalaire,Db:Db,etatSalaireBE:etatSalaireBE,mois2BE:mois2BE,avanceBE:avanceBE,pointageBE:pointageBE,heureSupBE:heureSupBE,QmanagerBE:QmanagerBE, fs:fs}

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '/public'));

// Assuming your CSS file is in the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
	// perform index.ejs  
	res.render('index', { title: 'LAUVE GRH', message: '' });
});//get started

app.get('/personnelInfo',async (req,res)=>{
	let db=new Db();
	let myPerso=new personnel(odbc,res,{conStr:db.cs});
	let allPersonnel=await myPerso.getListAllPers();
	res.json(allPersonnel);
})

app.get('/paramSalaireInfo',async (req,res)=>{
	// old method
	// let db=new Db();
	// let myparamSalaire= new paramSalaire(odbc,res,req,{conStr:db.cs});
	// const ps=await myparamSalaire.getParamSalaire();
	// res.json(ps);
	try {
		let db = new Db();
		let myparamSalaire = new paramSalaire(odbc, res, req, { conStr: db.cs, dependencyes:dependencyes });
		// Appel de la méthode asynchrone avec await
		const ps = await myparamSalaire.getParamSalaire();		
		// Envoi de la réponse
		res.json(ps);
	} catch (err) {
		console.error('Erreur:', err);
		res.status(500).json({ error: 'Erreur interne du serveur' });
	}
	
})

app.post('/importParamSalaire', upload.single('file'),async (req,res)=>{
	let db=new Db();
	let myparamSalaire= new paramSalaire(odbc,res,req,{conStr:db.cs, dependencyes:dependencyes});
	let r=await myparamSalaire.importParamSalaire(exceljs);
	res.json(r);
} );

app.post('/updtEtatSalairePointageI', upload.single('file'),async (req,res)=>{
	let db=new Db();
	let mois=req.body.mois;
	let rows=req.body.rows;
	let myEs= new etatSalaireBE(odbc,res,req,{conStr:db.cs, dependencyes:dependencyes, mois:mois});
	let r=await myEs.updt(rows);
	res.json(r);
} );

app.post('/getAllEtatSalaire',async(req,res)=>{
	// console.log(req.body);
	let db=new Db();
	const mois=req.body.mois;
	let myEs=new etatSalaireBE(odbc,res,req,{conStr:db.cs, mois:mois});
	let allEs=await myEs.getAllEtatSalaire();
	res.json(allEs);
	
});

app.post('/buildNewEtatSalaire',async(req,res)=>{
	// console.log(req.body);
	let db=new Db();
	const mois=req.body.mois;
	let myEs=new etatSalaireBE(odbc,res,req,{conStr:db.cs, mois:mois, dependencyes:dependencyes});
	let allEs=await myEs.buildNewEtatSalaire(paramSalaire);
	res.json(allEs);
	
});

app.post('/updtEtatSalairePersoInfo',async(req,res)=>{
	// console.log(req.body);
	let db=new Db();
	const mois=req.body.mois;
	const data=req.body.data;
	// console.log(data)
	// const EsStructur=req.body.EsStructur;
	// const personnelList=req.body.personnelList;
	let myEs=new etatSalaireBE(odbc,res,req,{conStr:db.cs, mois:mois, dependencyes:dependencyes});
	let allEs=await myEs.updtEtatSalaire12(data);
	res.json(allEs);
	
});

app.post('/exportEs',async(req,res)=>{
	let db=new Db();
	const mois=req.body.mois;
	let myEs=new etatSalaireBE(odbc,res,req,{conStr:db.cs, mois:mois, dependencyes:dependencyes});
	let exportAns=await myEs.export();
	res.json(exportAns);
})

app.post('/getAvanceData', async(req,res)=>{
	let db=new Db();
	const mois=req.body.mois;
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myAvance=new avanceBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const avanceData=await myAvance.getData();
	// console.log(avanceData);
	res.json(avanceData)
	
})

app.post('/getHeureSupData', async(req,res)=>{
	let db=new Db();
	const mois=req.body.mois;
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myHeureSup=new heureSupBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const heureSupData=await myHeureSup.getData();
	// console.log(avanceData);
	res.json(heureSupData)
	
})

app.post('/addHeureSupRow', async(req,res)=>{
	let db=new Db();
	const mois=req.body.mois;
	const rows=req.body.rows;
	const structure=req.body.structure;
	// console.log(rows)
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myHeureSup=new heureSupBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const rs=await myHeureSup.addRows(rows);
	// const heureSupData=await myHeureSup.getData();
	// console.log(avanceData);
	res.json(rs)
	
})

app.post('/importAvance', upload.single('file'),async (req,res)=>{
	let db=new Db();
	// let myparamSalaire= new paramSalaire(odbc,res,req,{conStr:db.cs, dependencyes:dependencyes});
	// let r=await myparamSalaire.importParamSalaire(exceljs);
	const mois=req.body.mois;
	// console.log(mois);
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myAvance=new avanceBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const r=await myAvance.importA();
	res.json(r);
} );

app.post('/getMoisInfos', async (req,res)=>{
	let db=new Db();
	
	const mois=req.body.mois;
	
	const mymois=new mois2BE( odbc, res, req, {conStr:db.cs, mois:mois, dependencyes:dependencyes}	);
	const r=await mymois.getInfoFromDb();
	res.json(r);
} );

app.post('/importAvance1', async (req,res)=>{
	let db=new Db();
	// let myparamSalaire= new paramSalaire(odbc,res,req,{conStr:db.cs, dependencyes:dependencyes});
	// let r=await myparamSalaire.importParamSalaire(exceljs);
	const mois=req.body.mois;
	let rows=req.body.rows;
	// console.log(rows);
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myAvance=new avanceBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const r=await myAvance.addRows(rows);
	res.json(r);
} );

app.post('/updtAvance', async (req,res)=>{
	let db=new Db();

	const mois=req.body.mois;
	let rows=req.body.rows;

	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myAvance=new avanceBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const r=await myAvance.updtAvance(rows);
	res.json(r);
} );

app.post('/deleteAvance',async(req,res)=>{
	let db=new Db();
	const mois=req.body.mois;
	const d=req.body.rows;
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myAvance=new avanceBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const r=await myAvance.deteleRows(d);
	res.json(r);
})

app.post('/getPointageData',async(req,res)=>{
	let db=new Db();
	const mois=req.body.mois;
	
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myPtge=new pointageBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const r=await myPtge.getData();
	res.json(r);
})

app.post('/addPointage',async(req,res)=>{
	let db=new Db();
	const mois=req.body.mois;
	const rows=req.body.rows;
	// console.log(rows)
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myPtge=new pointageBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const r=await myPtge.beforeInsert(rows);
	res.json(r);
})

app.post('/addRowPointage2',async(req,res)=>{
	let db=new Db();
	const structure=(typeof(req.body.structure)!="undefined")?req.body.structure:{} ;
	const ar=(typeof(req.body.rows)!="undefined")?req.body.rows:[] ;
	const mois=(typeof(req.body.mois)!="undefined")?req.body.mois:"" ;
	// console.log(rows)
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myPtge=new pointageBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	// console.log(dependencyes["fs"]);
	const r=await myPtge.addRowPointage2({ar:ar, structure:structure});
	res.json(r);
})

app.post('/updtRowPointage2', async (req,res)=>{
	let db=new Db();
	const rows=(typeof(req.body.rows)!="undefined")?req.body.rows:[] ;
	const mois=(typeof(req.body.mois)!="undefined")?req.body.mois:"" ;
	const CIN=(typeof(req.body.CIN)!="undefined" )?req.body.CIN:"" ;
	const myPtge=new pointageBE( odbc, res, req, {conStr:db.cs, mois:mois, CIN:CIN, dependencyes:dependencyes}	);
	const r=await myPtge.updtRowPointage2({rows:rows, tableName:"POINTAGZ2", id:"idPointage2"});
	res.json(r);
	
}  )


app.listen(port, '127.0.0.1', () => {
  console.log(`Server is running at http://127.0.0.1:${port}`);
});

